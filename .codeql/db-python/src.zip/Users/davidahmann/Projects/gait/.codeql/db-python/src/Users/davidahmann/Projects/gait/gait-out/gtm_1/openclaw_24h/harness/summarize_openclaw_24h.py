#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any


def parse_ts(value: str) -> datetime:
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    return datetime.fromisoformat(value)


def percentile(values: list[float], pct: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    idx = (len(ordered) - 1) * pct
    lo = math.floor(idx)
    hi = math.ceil(idx)
    if lo == hi:
        return ordered[lo]
    frac = idx - lo
    return ordered[lo] + (ordered[hi] - ordered[lo]) * frac


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        payload = json.loads(line)
        if isinstance(payload, dict):
            rows.append(payload)
    return rows


def read_metadata(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or "=" not in line:
            continue
        k, v = line.split("=", 1)
        values[k] = v
    return values


def main() -> int:
    parser = argparse.ArgumentParser(description="Summarize OpenClaw-envelope simulation outputs")
    parser.add_argument("--decisions", required=True)
    parser.add_argument("--verify", required=True)
    parser.add_argument("--metadata", required=True)
    parser.add_argument("--summary-out", required=True)
    args = parser.parse_args()

    decisions = read_jsonl(Path(args.decisions))
    verify_rows = read_jsonl(Path(args.verify))
    meta = read_metadata(Path(args.metadata))

    if not decisions:
        raise SystemExit("no decisions found")

    tool_set = set()
    verdict_counts: Counter[str] = Counter()
    reason_counts: Counter[str] = Counter()
    violation_counts: Counter[str] = Counter()
    latencies: list[float] = []
    blocked_examples: list[dict[str, Any]] = []

    for row in decisions:
        tool = str(row.get("input_tool", "")).strip()
        if tool:
            tool_set.add(tool)
        verdict = str(row.get("verdict", "")).strip() or "unknown"
        verdict_counts[verdict] += 1

        reasons = row.get("reason_codes", [])
        if isinstance(reasons, list):
            for reason in reasons:
                reason_counts[str(reason)] += 1

        violations = row.get("violations", [])
        if isinstance(violations, list):
            for violation in violations:
                violation_counts[str(violation)] += 1

        latency = row.get("latency_ms")
        if isinstance(latency, (int, float)):
            latencies.append(float(latency))

        if verdict == "block" and len(blocked_examples) < 10:
            blocked_examples.append(
                {
                    "tool": tool,
                    "reason_codes": reasons if isinstance(reasons, list) else [],
                    "trace_path": str(row.get("trace_path", "")),
                    "runpack_path": str(row.get("runpack_path", "")),
                }
            )

    sim_times = [parse_ts(str(r["simulated_time_utc"])) for r in decisions if r.get("simulated_time_utc")]
    wall_times = [parse_ts(str(r["timestamp_utc"])) for r in decisions if r.get("timestamp_utc")]

    sim_start = min(sim_times)
    sim_end = max(sim_times)
    wall_start = min(wall_times)
    wall_end = max(wall_times)

    verify_ok = 0
    for row in verify_rows:
        if bool(row.get("ok", False)):
            verify_ok += 1

    total_calls = len(decisions)
    blocks = verdict_counts.get("block", 0)

    summary = {
        "experiment_mode": "simulation",
        "openclaw_runtime_started": False,
        "openclaw_repo_snapshot": {
            "root": meta.get("openclaw_repo_root", ""),
            "commit": meta.get("openclaw_repo_commit", ""),
            "branch": meta.get("openclaw_repo_branch", ""),
        },
        "window": {
            "start_utc": sim_start.isoformat().replace("+00:00", "Z"),
            "end_utc": sim_end.isoformat().replace("+00:00", "Z"),
            "duration_seconds": int((sim_end - sim_start).total_seconds()),
            "wall_clock_seconds": round((wall_end - wall_start).total_seconds(), 3),
        },
        "calls": {
            "total": total_calls,
            "unique_tools": sorted(tool_set),
        },
        "verdict_counts": {
            "allow": verdict_counts.get("allow", 0),
            "block": verdict_counts.get("block", 0),
            "require_approval": verdict_counts.get("require_approval", 0),
            "dry_run": verdict_counts.get("dry_run", 0),
        },
        "block_rate": round((blocks / total_calls) if total_calls else 0.0, 6),
        "reason_code_counts": dict(reason_counts.most_common()),
        "violation_counts": dict(violation_counts.most_common()),
        "latency_ms": {
            "median": round(percentile(latencies, 0.5), 3),
            "p95": round(percentile(latencies, 0.95), 3),
        },
        "runpacks": {
            "total": len(verify_rows),
            "verify_ok": verify_ok,
            "verify_failed": len(verify_rows) - verify_ok,
        },
        "blocked_examples": blocked_examples,
    }

    out_path = Path(args.summary_out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
