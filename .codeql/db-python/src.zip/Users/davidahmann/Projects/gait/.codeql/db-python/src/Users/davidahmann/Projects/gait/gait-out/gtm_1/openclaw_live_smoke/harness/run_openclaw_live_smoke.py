#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import signal
import subprocess
import tempfile
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def iso_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def load_calls(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        payload = json.loads(line)
        if isinstance(payload, dict):
            rows.append(payload)
    if not rows:
        raise RuntimeError("no calls found")
    return rows


def parse_json_maybe(raw: str) -> dict[str, Any]:
    text = raw.strip()
    if not text:
        return {}
    try:
        payload = json.loads(text)
        return payload if isinstance(payload, dict) else {}
    except json.JSONDecodeError:
        first = text.find("{")
        last = text.rfind("}")
        if first >= 0 and last > first:
            chunk = text[first : last + 1]
            try:
                payload = json.loads(chunk)
                return payload if isinstance(payload, dict) else {}
            except json.JSONDecodeError:
                return {}
        return {}


def run_health(env: dict[str, str], openclaw_root: Path) -> tuple[bool, dict[str, Any], str]:
    cmd = ["node", "openclaw.mjs", "gateway", "health", "--json"]
    proc = subprocess.run(cmd, cwd=str(openclaw_root), env=env, text=True, capture_output=True, check=False)
    payload = parse_json_maybe(proc.stdout)
    ok = bool(payload.get("ok", False)) and proc.returncode == 0
    return ok, payload, proc.stderr.strip()


def run_skill(
    skill_entrypoint: Path,
    policy_path: Path,
    call_payload: dict[str, Any],
    trace_path: Path,
    runpack_path: Path,
) -> tuple[int, dict[str, Any], str]:
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".json", delete=False) as fh:
        json.dump(call_payload, fh, separators=(",", ":"), sort_keys=True)
        call_path = Path(fh.name)

    cmd = [
        "python3",
        str(skill_entrypoint),
        "--policy",
        str(policy_path),
        "--call",
        str(call_path),
        "--trace-out",
        str(trace_path),
        "--runpack-out",
        str(runpack_path),
        "--key-mode",
        "dev",
        "--json",
    ]
    proc = subprocess.run(cmd, text=True, capture_output=True, check=False)
    payload = parse_json_maybe(proc.stdout)
    call_path.unlink(missing_ok=True)
    return proc.returncode, payload, proc.stderr.strip()


def main() -> int:
    parser = argparse.ArgumentParser(description="Run live OpenClaw runtime smoke")
    parser.add_argument("--duration-minutes", type=int, default=30)
    parser.add_argument("--interval-seconds", type=int, default=30)
    parser.add_argument("--calls", required=True)
    parser.add_argument("--policy", required=True)
    parser.add_argument("--skill-entrypoint", required=True)
    parser.add_argument("--openclaw-root", required=True)
    parser.add_argument("--openclaw-home", required=True)
    parser.add_argument("--openclaw-state", required=True)
    parser.add_argument("--openclaw-config", required=True)
    parser.add_argument("--gateway-log", required=True)
    parser.add_argument("--decisions-out", required=True)
    parser.add_argument("--health-out", required=True)
    parser.add_argument("--trace-dir", required=True)
    parser.add_argument("--runpack-dir", required=True)
    parser.add_argument("--meta-out", required=True)
    args = parser.parse_args()

    calls = load_calls(Path(args.calls))
    policy = Path(args.policy)
    skill_entrypoint = Path(args.skill_entrypoint)
    openclaw_root = Path(args.openclaw_root)

    gateway_log = Path(args.gateway_log)
    decisions_out = Path(args.decisions_out)
    health_out = Path(args.health_out)
    trace_dir = Path(args.trace_dir)
    runpack_dir = Path(args.runpack_dir)
    meta_out = Path(args.meta_out)

    gateway_log.parent.mkdir(parents=True, exist_ok=True)
    decisions_out.parent.mkdir(parents=True, exist_ok=True)
    health_out.parent.mkdir(parents=True, exist_ok=True)
    trace_dir.mkdir(parents=True, exist_ok=True)
    runpack_dir.mkdir(parents=True, exist_ok=True)
    meta_out.parent.mkdir(parents=True, exist_ok=True)

    env = dict(**subprocess.os.environ)
    env["OPENCLAW_HOME"] = args.openclaw_home
    env["OPENCLAW_STATE_DIR"] = args.openclaw_state
    env["OPENCLAW_CONFIG_PATH"] = args.openclaw_config
    env["OPENCLAW_SKIP_CHANNELS"] = "1"
    env["OPENCLAW_SKIP_CANVAS_HOST"] = "1"

    gateway_cmd = [
        "node",
        "openclaw.mjs",
        "gateway",
        "run",
        "--allow-unconfigured",
        "--force",
        "--port",
        "18989",
        "--bind",
        "loopback",
        "--token",
        "gtm_live_smoke_token",
        "--verbose",
    ]

    start_utc = iso_now()
    start_wall = time.monotonic()

    with gateway_log.open("w", encoding="utf-8") as log_fp:
        gateway_proc = subprocess.Popen(
            gateway_cmd,
            cwd=str(openclaw_root),
            env=env,
            stdout=log_fp,
            stderr=subprocess.STDOUT,
            text=True,
        )

    ready = False
    for _ in range(24):
        ok, payload, stderr = run_health(env=env, openclaw_root=openclaw_root)
        row = {
            "timestamp_utc": iso_now(),
            "phase": "startup_probe",
            "ok": ok,
            "stderr": stderr,
            "payload": payload,
        }
        with health_out.open("a", encoding="utf-8") as hf:
            hf.write(json.dumps(row, separators=(",", ":"), sort_keys=True) + "\n")
        if ok:
            ready = True
            break
        time.sleep(5)

    if not ready:
        gateway_proc.send_signal(signal.SIGINT)
        try:
            gateway_proc.wait(timeout=20)
        except subprocess.TimeoutExpired:
            gateway_proc.kill()
        raise RuntimeError("gateway did not become healthy")

    duration_seconds = max(60, args.duration_minutes * 60)
    interval = max(5, args.interval_seconds)
    iterations = max(1, duration_seconds // interval)

    with decisions_out.open("w", encoding="utf-8") as decisions_fp:
        for i in range(iterations):
            loop_start = time.monotonic()
            call_payload = calls[i % len(calls)]
            tool = ""
            tool_call = call_payload.get("tool_call", {}) if isinstance(call_payload, dict) else {}
            if isinstance(tool_call, dict):
                tool = str(tool_call.get("tool", ""))

            trace_path = trace_dir / f"trace_live_{i + 1:04d}.json"
            runpack_path = runpack_dir / f"runpack_live_{i + 1:04d}.zip"

            rc, payload, stderr = run_skill(
                skill_entrypoint=skill_entrypoint,
                policy_path=policy,
                call_payload=call_payload,
                trace_path=trace_path,
                runpack_path=runpack_path,
            )

            health_ok, health_payload, health_stderr = run_health(env=env, openclaw_root=openclaw_root)
            health_row = {
                "timestamp_utc": iso_now(),
                "phase": "loop",
                "iteration": i + 1,
                "ok": health_ok,
                "stderr": health_stderr,
                "payload": health_payload,
            }
            with health_out.open("a", encoding="utf-8") as hf:
                hf.write(json.dumps(health_row, separators=(",", ":"), sort_keys=True) + "\n")

            decision = {
                "timestamp_utc": iso_now(),
                "iteration": i + 1,
                "input_tool": tool,
                "exit_code": rc,
                "verdict": str(payload.get("verdict", "")),
                "reason_codes": payload.get("reason_codes", []) if isinstance(payload.get("reason_codes", []), list) else [],
                "violations": payload.get("violations", []) if isinstance(payload.get("violations", []), list) else [],
                "trace_path": str(payload.get("trace_path", str(trace_path))),
                "runpack_path": str(payload.get("runpack_path", str(runpack_path))),
                "gateway_health_ok": health_ok,
                "stderr": stderr,
            }
            decisions_fp.write(json.dumps(decision, separators=(",", ":"), sort_keys=True) + "\n")
            decisions_fp.flush()

            elapsed = time.monotonic() - loop_start
            sleep_for = interval - elapsed
            if sleep_for > 0:
                time.sleep(sleep_for)

    gateway_proc.send_signal(signal.SIGINT)
    try:
        gateway_proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        gateway_proc.terminate()
        try:
            gateway_proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            gateway_proc.kill()

    end_utc = iso_now()
    wall_seconds = round(time.monotonic() - start_wall, 3)

    meta = {
        "experiment_mode": "live_smoke",
        "openclaw_runtime_started": True,
        "duration_minutes": args.duration_minutes,
        "interval_seconds": interval,
        "iterations": iterations,
        "started_at_utc": start_utc,
        "ended_at_utc": end_utc,
        "wall_clock_seconds": wall_seconds,
    }
    meta_out.write_text(json.dumps(meta, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
