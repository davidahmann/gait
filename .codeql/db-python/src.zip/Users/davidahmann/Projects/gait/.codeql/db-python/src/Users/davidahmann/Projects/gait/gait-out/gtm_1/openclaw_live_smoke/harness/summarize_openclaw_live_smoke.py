#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not path.exists():
        return rows
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        payload = json.loads(line)
        if isinstance(payload, dict):
            rows.append(payload)
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Summarize live smoke outputs")
    parser.add_argument("--meta", required=True)
    parser.add_argument("--decisions", required=True)
    parser.add_argument("--health", required=True)
    parser.add_argument("--verify", required=True)
    parser.add_argument("--summary-out", required=True)
    parser.add_argument("--addendum-out", required=True)
    parser.add_argument("--blog", required=True)
    parser.add_argument("--dm", required=True)
    args = parser.parse_args()

    meta = json.loads(Path(args.meta).read_text(encoding="utf-8"))
    decisions = read_jsonl(Path(args.decisions))
    health = read_jsonl(Path(args.health))
    verify = read_jsonl(Path(args.verify))

    verdict_counts: Counter[str] = Counter()
    for d in decisions:
        verdict_counts[str(d.get("verdict", "unknown"))] += 1

    health_total = len(health)
    health_ok = sum(1 for h in health if bool(h.get("ok", False)))

    runpacks_total = len(verify)
    runpacks_ok = sum(1 for v in verify if bool(v.get("ok", False)))

    summary = {
        "experiment_mode": "live_smoke",
        "openclaw_runtime_started": True,
        "duration_minutes": meta.get("duration_minutes"),
        "iterations": meta.get("iterations"),
        "window": {
            "start_utc": meta.get("started_at_utc"),
            "end_utc": meta.get("ended_at_utc"),
            "wall_clock_seconds": meta.get("wall_clock_seconds"),
        },
        "gateway_health_checks_total": health_total,
        "gateway_health_checks_ok": health_ok,
        "gateway_health_ok_rate": round((health_ok / health_total), 6) if health_total else 0.0,
        "verdict_counts": {
            "allow": verdict_counts.get("allow", 0),
            "block": verdict_counts.get("block", 0),
            "require_approval": verdict_counts.get("require_approval", 0),
            "dry_run": verdict_counts.get("dry_run", 0),
        },
        "runpacks_total": runpacks_total,
        "runpacks_verify_ok": runpacks_ok,
        "runpacks_verify_failed": runpacks_total - runpacks_ok,
    }

    Path(args.summary_out).write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    addendum = f"""# Live Runtime Smoke Addendum (30m)

This follow-up used a real OpenClaw gateway runtime with isolated local config and no external channels.

- experiment_mode: `live_smoke`
- openclaw_runtime_started: `true`
- duration_minutes: {summary['duration_minutes']}
- iterations: {summary['iterations']}
- gateway_health_checks_ok_rate: {summary['gateway_health_ok_rate']}
- verdict_counts: {summary['verdict_counts']}
- runpacks_verify_ok: {summary['runpacks_verify_ok']}/{summary['runpacks_total']}

Scope note: this validates runtime/transport assumptions and boundary wiring, not full external channel behavior.
"""
    Path(args.addendum_out).write_text(addendum, encoding="utf-8")

    blog_path = Path(args.blog)
    blog_text = blog_path.read_text(encoding="utf-8")
    section = f"""

## Live Runtime Smoke Follow-up (30m)

A separate live runtime smoke was run with isolated config and no external channels.

- Gateway health checks OK: {summary['gateway_health_checks_ok']}/{summary['gateway_health_checks_total']} ({summary['gateway_health_ok_rate']})
- Verdict counts: allow={summary['verdict_counts']['allow']}, block={summary['verdict_counts']['block']}, require_approval={summary['verdict_counts']['require_approval']}
- Runpacks verified: {summary['runpacks_verify_ok']}/{summary['runpacks_total']}

This validates transport/runtime assumptions for the OpenClaw + Gait boundary path without re-running the full GTM experiment.
"""
    if "## Live Runtime Smoke Follow-up (30m)" not in blog_text:
        blog_path.write_text(blog_text.rstrip() + section + "\n", encoding="utf-8")

    dm_path = Path(args.dm)
    dm_text = dm_path.read_text(encoding="utf-8").rstrip()
    extra = (
        f"\n4) Live runtime smoke (30m, isolated OpenClaw gateway): health OK "
        f"{summary['gateway_health_checks_ok']}/{summary['gateway_health_checks_total']}, "
        f"runpacks verified {summary['runpacks_verify_ok']}/{summary['runpacks_total']}"
    )
    if "Live runtime smoke (30m" not in dm_text:
        dm_path.write_text(dm_text + extra + "\n", encoding="utf-8")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
