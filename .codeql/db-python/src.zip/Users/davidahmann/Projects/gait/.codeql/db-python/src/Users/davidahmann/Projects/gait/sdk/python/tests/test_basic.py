def test_import() -> None:
    import gait

    assert gait.__version__
