#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import tempfile
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any


def iso_utc(dt: datetime) -> str:
    return dt.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def load_calls(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        payload = json.loads(line)
        if not isinstance(payload, dict):
            raise ValueError("calls row must be object")
        rows.append(payload)
    if not rows:
        raise ValueError("calls file has no rows")
    return rows


def run_once(
    entrypoint: Path,
    policy: Path,
    call_payload: dict[str, Any],
    trace_path: Path,
    runpack_path: Path,
) -> tuple[int, dict[str, Any], str]:
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".json", delete=False) as fh:
        json.dump(call_payload, fh, separators=(",", ":"), sort_keys=True)
        call_path = Path(fh.name)

    command = [
        "python3",
        str(entrypoint),
        "--policy",
        str(policy),
        "--call",
        str(call_path),
        "--trace-out",
        str(trace_path),
        "--runpack-out",
        str(runpack_path),
        "--key-mode",
        "dev",
        "--json",
    ]

    completed = subprocess.run(command, text=True, capture_output=True, check=False)
    stderr = completed.stderr.strip()
    stdout = completed.stdout.strip()
    try:
        payload = json.loads(stdout) if stdout else {}
    except json.JSONDecodeError:
        payload = {"ok": False, "error": "invalid_json", "raw_stdout": stdout}
    finally:
        call_path.unlink(missing_ok=True)

    if not isinstance(payload, dict):
        payload = {"ok": False, "error": "non_object_json", "raw_stdout": stdout}
    return completed.returncode, payload, stderr


def main() -> int:
    parser = argparse.ArgumentParser(description="Run OpenClaw-envelope 24h-equivalent simulation")
    parser.add_argument("--iterations", type=int, default=2880)
    parser.add_argument("--equivalent-interval-seconds", type=int, default=30)
    parser.add_argument("--calls", required=True)
    parser.add_argument("--policy", required=True)
    parser.add_argument("--entrypoint", required=True)
    parser.add_argument("--trace-dir", required=True)
    parser.add_argument("--runpack-dir", required=True)
    parser.add_argument("--decisions-out", required=True)
    parser.add_argument("--log-out", required=True)
    args = parser.parse_args()

    calls = load_calls(Path(args.calls))
    policy = Path(args.policy)
    entrypoint = Path(args.entrypoint)
    trace_dir = Path(args.trace_dir)
    runpack_dir = Path(args.runpack_dir)
    decisions_out = Path(args.decisions_out)
    log_out = Path(args.log_out)

    trace_dir.mkdir(parents=True, exist_ok=True)
    runpack_dir.mkdir(parents=True, exist_ok=True)
    decisions_out.parent.mkdir(parents=True, exist_ok=True)
    log_out.parent.mkdir(parents=True, exist_ok=True)

    start_wall = time.monotonic()
    start_utc = datetime.now(UTC)

    with decisions_out.open("w", encoding="utf-8") as decisions_fp, log_out.open("w", encoding="utf-8") as log_fp:
        log_fp.write(
            json.dumps(
                {
                    "event": "start",
                    "started_at_utc": iso_utc(start_utc),
                    "iterations": args.iterations,
                    "equivalent_interval_seconds": args.equivalent_interval_seconds,
                    "experiment_mode": "simulation",
                    "openclaw_runtime_started": False,
                },
                separators=(",", ":"),
                sort_keys=True,
            )
            + "\n"
        )
        log_fp.flush()

        for i in range(args.iterations):
            row = calls[i % len(calls)]
            tool_call = row.get("tool_call", {}) if isinstance(row, dict) else {}
            input_tool = ""
            if isinstance(tool_call, dict):
                input_tool = str(tool_call.get("tool", ""))

            trace_path = trace_dir / f"trace_{i + 1:06d}.json"
            runpack_path = runpack_dir / f"runpack_{i + 1:06d}.zip"

            simulated_at = start_utc + timedelta(seconds=i * args.equivalent_interval_seconds)
            invoke_start = time.monotonic()
            exit_code, payload, stderr = run_once(
                entrypoint=entrypoint,
                policy=policy,
                call_payload=row,
                trace_path=trace_path,
                runpack_path=runpack_path,
            )
            latency_ms = (time.monotonic() - invoke_start) * 1000.0
            now_utc = datetime.now(UTC)

            reason_codes = payload.get("reason_codes", [])
            violations = payload.get("violations", [])
            if not isinstance(reason_codes, list):
                reason_codes = []
            if not isinstance(violations, list):
                violations = []

            decision = {
                "index": i + 1,
                "timestamp_utc": iso_utc(now_utc),
                "simulated_time_utc": iso_utc(simulated_at),
                "experiment_mode": "simulation",
                "openclaw_runtime_started": False,
                "input_tool": input_tool,
                "exit_code": exit_code,
                "latency_ms": round(latency_ms, 3),
                "ok": bool(payload.get("ok", False)),
                "verdict": str(payload.get("verdict", "")),
                "reason_codes": reason_codes,
                "violations": violations,
                "trace_path": str(payload.get("trace_path", str(trace_path))),
                "runpack_path": str(payload.get("runpack_path", str(runpack_path))),
                "intent_digest": str(payload.get("intent_digest", "")),
                "policy_digest": str(payload.get("policy_digest", "")),
                "error": str(payload.get("error", "")),
                "stderr": stderr,
            }
            decisions_fp.write(json.dumps(decision, separators=(",", ":"), sort_keys=True) + "\n")

            if (i + 1) % 120 == 0:
                elapsed_wall = time.monotonic() - start_wall
                progress = {
                    "event": "heartbeat",
                    "iteration": i + 1,
                    "iterations": args.iterations,
                    "simulated_at_utc": iso_utc(simulated_at),
                    "elapsed_wall_seconds": round(elapsed_wall, 3),
                }
                log_fp.write(json.dumps(progress, separators=(",", ":"), sort_keys=True) + "\n")
                log_fp.flush()

        end_utc = datetime.now(UTC)
        elapsed = time.monotonic() - start_wall
        log_fp.write(
            json.dumps(
                {
                    "event": "complete",
                    "completed_at_utc": iso_utc(end_utc),
                    "elapsed_wall_seconds": round(elapsed, 3),
                    "iterations": args.iterations,
                },
                separators=(",", ":"),
                sort_keys=True,
            )
            + "\n"
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
