#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Render GTM content from summary.json")
    parser.add_argument("--summary", required=True)
    parser.add_argument("--inspect", required=True)
    parser.add_argument("--content-dir", required=True)
    parser.add_argument("--artifact-bundle", required=True)
    args = parser.parse_args()

    summary = json.loads(Path(args.summary).read_text(encoding="utf-8"))
    inspect_lines = [line for line in Path(args.inspect).read_text(encoding="utf-8").splitlines() if line.strip()]

    content_dir = Path(args.content_dir)
    content_dir.mkdir(parents=True, exist_ok=True)

    total = summary["calls"]["total"]
    block_count = summary["verdict_counts"]["block"]
    allow_count = summary["verdict_counts"]["allow"]
    approval_count = summary["verdict_counts"]["require_approval"]
    block_rate = summary["block_rate"]
    p95 = summary["latency_ms"]["p95"]
    median = summary["latency_ms"]["median"]
    verify_ok = summary["runpacks"]["verify_ok"]
    verify_total = summary["runpacks"]["total"]

    disclaimer = (
        "This was an OpenClaw-envelope simulation using the official Gait OpenClaw skill entrypoint; "
        "it did not run a live OpenClaw channel/runtime stack."
    )

    top_reasons = list(summary.get("reason_code_counts", {}).items())[:5]
    reasons_md = "\n".join([f"- `{k}`: {v}" for k, v in top_reasons]) or "- none"

    blog = f"""# OpenClaw in 24 Hours (Simulation): Boundary Enforcement Results

{disclaimer}

## Setup

- Policy path: `gait-out/gtm_1/openclaw_24h/config/policy_experiment.yaml`
- Entry point: `gait-out/gtm_1/openclaw_24h/openclaw/skills/gait-gate/gait_openclaw_gate.py`
- Mode: `experiment_mode=simulation`, `openclaw_runtime_started=false`

## Methodology

- Time-compressed simulation equivalent: ~24h window
- Equivalent interval: 30 seconds
- Total evaluated calls: {total}
- Call source: OpenClaw-style envelope seed corpus (`calls_seed.jsonl`) in round-robin

## Results

| Metric | Value |
|---|---|
| Total calls | {total} |
| Allow | {allow_count} |
| Block | {block_count} |
| Require approval | {approval_count} |
| Block rate | {block_rate} |
| Latency median (ms) | {median} |
| Latency p95 (ms) | {p95} |
| Runpacks verified | {verify_ok}/{verify_total} |

## What Was Blocked

{reasons_md}

## What Runpacks Revealed

- Deterministic trace + runpack artifacts were produced per evaluated call.
- Blocked trajectories are inspectable with `gait run inspect`.
- Sample blocked inspections captured: {len(inspect_lines)} records.

## Repro Steps

1. Run policy preflight: `policy validate`, `policy fmt`, `policy test`, `policy simulate`.
2. Install isolated OpenClaw skill package (`install_openclaw_skill.sh`).
3. Execute simulation harness (`run_openclaw_24h_sim.py`).
4. Verify runpacks + summarize (`summarize_openclaw_24h.py`).

Artifacts:
- Summary: `gait-out/gtm_1/openclaw_24h/results/summary.json`
- Decisions: `gait-out/gtm_1/openclaw_24h/runtime/decisions.jsonl`
- Bundle: `{args.artifact_bundle}`

## Limitations

- Simulation validates boundary behavior, not end-to-end OpenClaw channel runtime behavior.
- Workload comes from seeded envelopes, not organically generated traffic.

## Next Iteration

- Run a short live-runtime smoke against local OpenClaw gateway with the same policy and compare verdict distribution.
"""

    linkedin = f"""{disclaimer}

Ran a 24h-equivalent OpenClaw-envelope boundary simulation with Gait:
- calls evaluated: {total}
- blocked: {block_count} ({block_rate})
- runpacks verified: {verify_ok}/{verify_total}

Key point: every decision produced trace + runpack evidence and blocked trajectories were inspectable offline.

Report + artifacts: gait-out/gtm_1/openclaw_24h/content/openclaw_24h_blog.md
"""

    reddit = f"""We ran an OpenClaw-envelope simulation (not live runtime) through the official Gait OpenClaw skill entrypoint.

{disclaimer}

Results:
- total calls: {total}
- allow: {allow_count}
- block: {block_count}
- require_approval: {approval_count}
- block rate: {block_rate}
- runpacks verified: {verify_ok}/{verify_total}

Happy to share the exact command sequence and artifact bundle structure if useful.
"""

    dm = f"""1) 90s demo: gait-out/gtm_1/90s/gait_demo.mp4
2) OpenClaw-envelope simulation result: {block_count} blocked out of {total} calls, runpacks verified {verify_ok}/{verify_total}
3) Full report + artifacts: gait-out/gtm_1/openclaw_24h/content/openclaw_24h_blog.md and {args.artifact_bundle}
"""

    (content_dir / "openclaw_24h_blog.md").write_text(blog.strip() + "\n", encoding="utf-8")
    (content_dir / "linkedin_post.md").write_text(linkedin.strip() + "\n", encoding="utf-8")
    (content_dir / "reddit_post.md").write_text(reddit.strip() + "\n", encoding="utf-8")
    (content_dir / "dm_snippet.md").write_text(dm.strip() + "\n", encoding="utf-8")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
